#!/bin/bash

function show_help {
    echo -e "\nUso: $0 [-h] <directorio_origen> <directorio_destino>"
    echo -e "-h: Muestra esta ayuda\n"
    exit 0
}

if [[ "$1" == "-h" ]]; then
    show_help
fi

if [[ $# -ne 2 ]]; then
    echo -e "\nError: Se requieren dos argumentos: directorio_origen y directorio_destino.\n"
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"
FECHA=$(date +%Y%m%d)

if [[ ! -d "$ORIGEN" ]]; then
    echo -e "\nError: El directorio de origen $ORIGEN no existe.\n"
    exit 1
fi

if [[ ! -d "$DESTINO" ]]; then
    echo -e "\nError: El directorio de destino $DESTINO no existe.\n"
    exit 1
fi

NOMBRE_BACKUP="${ORIGEN##*/}_bkp_${FECHA}.tar.gz"
tar -czf "$DESTINO/$NOMBRE_BACKUP" "$ORIGEN"

if [[ $? -eq 0 ]]; then
    echo -e "\nBackup realizado con éxito: $DESTINO/$NOMBRE_BACKUP\n"
else
    echo -e "\nError al crear el backup.\n"
    exit 1
fi
